Put all your configs for this app by creating a local folder inside etc/<app-name>. Splunk Web will write out configs there, too.
